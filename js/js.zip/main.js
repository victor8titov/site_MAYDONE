/*
*           Custom code javaScript
*           Место для твоего кода  
*/

//It sturt after loading all elements DOM
$(function() {
    /*
    *       настройка и запуск слайдера
    */
    $('.slick').slick({
        dots: false,
        //infinite: true,
        //speed: 300,
        slidesToShow: 1,
        //adaptiveHeight: true
        prevArrow: '.prev',
        nextArrow: '.next',
        fade: true,
    });
    
    /*
    *   плавная прокрутка на форму обратной связи
    */
    $('.but').on('click', function() {
        $('html, body').animate({
            scrollTop: $('.feedback').offset().top
        }, 1000);
        return false;
    });

    /*
    *       анимация появления блоков страницы
    */
    $('header, footer, .option, .services, .feedback, .quote').css({opacity: 0.0}).animateScroll({classToAdd: 'animated fadeIn'});

    /*
    *       Обработка form
    */
   $('#feedback').on('submit', function() {
        $('#submit').val('send...');
        
        $.ajax({
            url: 'feedback.php',
            method: 'POST',
            data: $('#feedback').serialize(),
            success: function(data) {                
                if (data === 'true') {
                    $('.message_send p').text('Письмо отправлено. Спасибо!');
                    show_hidden_window();
                } else if (data === 'false') {
                    $('.message_send p').text('Письмо не получилось отправить. Попробуйте еще!');
                    show_hidden_window();
                }

                function show_hidden_window () {
                    $('.message_send').removeClass('flipOutY').addClass('animated flipInY');                    
                    setTimeout(hidden, 8000);   
                }                
                $('#submit').val('contact us now');
            }
        })
    
        return false;
   })
   function hidden() {
    $('.message_send').removeClass('flipInY').addClass('animated flipOutY'); 
   }
   $('#message_ok').on('click', function() {
       hidden();
       return false;
   })
});
